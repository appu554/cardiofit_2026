// Package ingestion implements pipelines for ingesting drug data from regulatory sources.
// This package handles FDA DailyMed SPL, TGA Product Information, and CDSCO package inserts.
package ingestion

import (
	"context"
	"encoding/xml"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"time"

	"gopkg.in/yaml.v3"
)

// =============================================================================
// FDA DAILYMED SPL INGESTION
// =============================================================================

// FDAIngestionPipeline ingests drug labels from FDA DailyMed SPL.
type FDAIngestionPipeline struct {
	outputDir    string
	httpClient   *http.Client
	dailyMedBase string
}

// NewFDAIngestionPipeline creates a new FDA ingestion pipeline.
func NewFDAIngestionPipeline(outputDir string) *FDAIngestionPipeline {
	return &FDAIngestionPipeline{
		outputDir:    outputDir,
		httpClient:   &http.Client{Timeout: 30 * time.Second},
		dailyMedBase: "https://dailymed.nlm.nih.gov/dailymed/services/v2",
	}
}

// SPLDocument represents a simplified FDA SPL document structure.
// Full SPL is complex HL7 XML; this captures key dosing sections.
type SPLDocument struct {
	SetID       string `xml:"setId"`
	VersionNumber string
	
	// Document sections we care about for dosing
	Sections []SPLSection
}

// SPLSection represents a section of the SPL document.
type SPLSection struct {
	Code  string // LOINC code for section type
	Title string
	Text  string
}

// Section LOINC codes for FDA SPL
const (
	SPLSectionDosageAdmin      = "34068-7" // DOSAGE AND ADMINISTRATION
	SPLSectionContraindications = "34070-3" // CONTRAINDICATIONS
	SPLSectionWarnings         = "34071-1" // WARNINGS AND PRECAUTIONS
	SPLSectionBlackBox         = "34066-1" // BOXED WARNING
	SPLSectionUseSpecificPops  = "43684-0" // USE IN SPECIFIC POPULATIONS
	SPLSectionClinPharm        = "34090-1" // CLINICAL PHARMACOLOGY
)

// FDADosingExtract represents extracted dosing information from FDA label.
type FDADosingExtract struct {
	SetID           string    `yaml:"setId"`
	DrugName        string    `yaml:"drugName"`
	RxNormCodes     []string  `yaml:"rxnormCodes"`
	ExtractedAt     time.Time `yaml:"extractedAt"`
	
	// Extracted sections
	DosageAndAdmin  string `yaml:"dosageAndAdmin"`
	Contraindications string `yaml:"contraindications"`
	Warnings        string `yaml:"warnings"`
	BlackBoxWarning string `yaml:"blackBoxWarning,omitempty"`
	SpecificPops    string `yaml:"specificPopulations,omitempty"`
	
	// Parsed dosing (semi-structured)
	ParsedDosing *ParsedDosing `yaml:"parsedDosing,omitempty"`
	
	// Review status
	ReviewStatus string `yaml:"reviewStatus"` // PENDING, REVIEWED, APPROVED
	ReviewedBy   string `yaml:"reviewedBy,omitempty"`
	ReviewedAt   string `yaml:"reviewedAt,omitempty"`
}

// ParsedDosing represents semi-structured dosing extracted from text.
type ParsedDosing struct {
	AdultDoses       []ExtractedDose `yaml:"adultDoses,omitempty"`
	PediatricDoses   []ExtractedDose `yaml:"pediatricDoses,omitempty"`
	RenalAdjustments []ExtractedAdjustment `yaml:"renalAdjustments,omitempty"`
	HepaticAdjustments []ExtractedAdjustment `yaml:"hepaticAdjustments,omitempty"`
	MaxDailyDose     string `yaml:"maxDailyDose,omitempty"`
	BlackBox         bool   `yaml:"blackBox"`
}

// ExtractedDose represents a dose extracted from label text.
type ExtractedDose struct {
	Indication string `yaml:"indication"`
	Dose       string `yaml:"dose"`
	Frequency  string `yaml:"frequency,omitempty"`
	Route      string `yaml:"route,omitempty"`
	Notes      string `yaml:"notes,omitempty"`
}

// ExtractedAdjustment represents an adjustment extracted from label text.
type ExtractedAdjustment struct {
	Condition  string `yaml:"condition"` // e.g., "CrCl 30-60"
	Adjustment string `yaml:"adjustment"` // e.g., "50% reduction"
	Notes      string `yaml:"notes,omitempty"`
}

// IngestFromSetID ingests a single drug from its FDA SetID.
func (p *FDAIngestionPipeline) IngestFromSetID(ctx context.Context, setID string) (*FDADosingExtract, error) {
	// Fetch SPL document
	url := fmt.Sprintf("%s/spls/%s.xml", p.dailyMedBase, setID)
	
	req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
	if err != nil {
		return nil, err
	}
	
	resp, err := p.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("failed to fetch SPL: %w", err)
	}
	defer resp.Body.Close()
	
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("FDA returned status %d", resp.StatusCode)
	}
	
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}
	
	// Parse SPL XML (simplified - full SPL parsing is complex)
	extract, err := p.parseSPL(setID, body)
	if err != nil {
		return nil, fmt.Errorf("failed to parse SPL: %w", err)
	}
	
	// Attempt to parse dosing from text
	extract.ParsedDosing = p.attemptDosingParse(extract)
	
	// Save to output directory
	if err := p.saveExtract(extract); err != nil {
		return nil, fmt.Errorf("failed to save extract: %w", err)
	}
	
	return extract, nil
}

// parseSPL parses the SPL XML document (simplified).
func (p *FDAIngestionPipeline) parseSPL(setID string, data []byte) (*FDADosingExtract, error) {
	extract := &FDADosingExtract{
		SetID:        setID,
		ExtractedAt:  time.Now(),
		ReviewStatus: "PENDING",
	}
	
	// This is a simplified parser. Real SPL parsing requires handling
	// the full HL7 CDA structure. For production, consider using
	// a dedicated SPL parsing library.
	
	// Extract drug name
	drugNameRe := regexp.MustCompile(`<title>([^<]+)</title>`)
	if matches := drugNameRe.FindSubmatch(data); len(matches) > 1 {
		extract.DrugName = strings.TrimSpace(string(matches[1]))
	}
	
	// Extract sections by LOINC code
	extract.DosageAndAdmin = p.extractSection(data, SPLSectionDosageAdmin)
	extract.Contraindications = p.extractSection(data, SPLSectionContraindications)
	extract.Warnings = p.extractSection(data, SPLSectionWarnings)
	extract.BlackBoxWarning = p.extractSection(data, SPLSectionBlackBox)
	extract.SpecificPops = p.extractSection(data, SPLSectionUseSpecificPops)
	
	return extract, nil
}

// extractSection extracts text from an SPL section by LOINC code.
func (p *FDAIngestionPipeline) extractSection(data []byte, loincCode string) string {
	// Simplified extraction - real implementation needs proper XML parsing
	pattern := fmt.Sprintf(`code code="%s".*?<text>(.*?)</text>`, loincCode)
	re := regexp.MustCompile(pattern)
	
	if matches := re.FindSubmatch(data); len(matches) > 1 {
		// Strip HTML tags
		text := string(matches[1])
		tagRe := regexp.MustCompile(`<[^>]+>`)
		text = tagRe.ReplaceAllString(text, " ")
		text = strings.Join(strings.Fields(text), " ")
		return text
	}
	
	return ""
}

// attemptDosingParse attempts to parse structured dosing from section text.
func (p *FDAIngestionPipeline) attemptDosingParse(extract *FDADosingExtract) *ParsedDosing {
	parsed := &ParsedDosing{
		BlackBox: extract.BlackBoxWarning != "",
	}
	
	text := extract.DosageAndAdmin
	
	// Look for max dose patterns
	maxDoseRe := regexp.MustCompile(`(?i)maximum\s+(?:daily\s+)?dose[:\s]+(\d+(?:\.\d+)?\s*(?:mg|g|mcg|units))`)
	if matches := maxDoseRe.FindStringSubmatch(text); len(matches) > 1 {
		parsed.MaxDailyDose = matches[1]
	}
	
	// Look for renal adjustment patterns
	renalRe := regexp.MustCompile(`(?i)(CrCl|eGFR|creatinine clearance)[:\s]*(\d+(?:-\d+)?)[:\s]*(.*?(?:avoid|reduce|contraindicated|decrease)[^.]*\.)`)
	if matches := renalRe.FindAllStringSubmatch(text, -1); len(matches) > 0 {
		for _, m := range matches {
			parsed.RenalAdjustments = append(parsed.RenalAdjustments, ExtractedAdjustment{
				Condition:  fmt.Sprintf("%s %s", m[1], m[2]),
				Adjustment: m[3],
			})
		}
	}
	
	// Look for dose patterns (simplified)
	doseRe := regexp.MustCompile(`(?i)(\d+(?:\.\d+)?)\s*(mg|g|mcg|units)(?:\s+(?:once|twice|three times|four times)\s+daily|\s+(?:q\d+h|bid|tid|qid|daily))`)
	if matches := doseRe.FindAllStringSubmatch(text, -1); len(matches) > 0 {
		for _, m := range matches {
			parsed.AdultDoses = append(parsed.AdultDoses, ExtractedDose{
				Dose:  fmt.Sprintf("%s %s", m[1], m[2]),
				Notes: "Auto-extracted - requires clinical review",
			})
		}
	}
	
	return parsed
}

// saveExtract saves the extract to a YAML file for clinical review.
func (p *FDAIngestionPipeline) saveExtract(extract *FDADosingExtract) error {
	// Create pending review directory
	pendingDir := filepath.Join(p.outputDir, "_pending_review", "us")
	if err := os.MkdirAll(pendingDir, 0755); err != nil {
		return err
	}
	
	// Generate filename
	safeName := strings.ReplaceAll(strings.ToLower(extract.DrugName), " ", "_")
	safeName = regexp.MustCompile(`[^a-z0-9_]`).ReplaceAllString(safeName, "")
	filename := filepath.Join(pendingDir, fmt.Sprintf("%s_%s.yaml", safeName, extract.SetID[:8]))
	
	// Marshal to YAML
	data, err := yaml.Marshal(extract)
	if err != nil {
		return err
	}
	
	// Write file
	return os.WriteFile(filename, data, 0644)
}

// =============================================================================
// TGA PRODUCT INFORMATION INGESTION
// =============================================================================

// TGAIngestionPipeline ingests drug labels from TGA Product Information.
type TGAIngestionPipeline struct {
	outputDir  string
	httpClient *http.Client
}

// NewTGAIngestionPipeline creates a new TGA ingestion pipeline.
func NewTGAIngestionPipeline(outputDir string) *TGAIngestionPipeline {
	return &TGAIngestionPipeline{
		outputDir:  outputDir,
		httpClient: &http.Client{Timeout: 60 * time.Second},
	}
}

// TGADosingExtract represents extracted dosing from TGA PI.
type TGADosingExtract struct {
	ARTGID      string    `yaml:"artgId"` // Australian Register of Therapeutic Goods ID
	DrugName    string    `yaml:"drugName"`
	Sponsor     string    `yaml:"sponsor"`
	ExtractedAt time.Time `yaml:"extractedAt"`
	
	// TGA PI sections
	Section42Dose          string `yaml:"section42Dose"`           // 4.2 Dose and method of administration
	Section43Contraind     string `yaml:"section43Contraind"`      // 4.3 Contraindications
	Section44Warnings      string `yaml:"section44Warnings"`       // 4.4 Special warnings
	Section46SpecialPops   string `yaml:"section46SpecialPops"`    // 4.6 Pregnancy/lactation
	Section52Pharmacokin   string `yaml:"section52Pharmacokin"`    // 5.2 Pharmacokinetic properties
	
	// AMT mapping
	AMTCodes []string `yaml:"amtCodes,omitempty"`
	
	// Review status
	ReviewStatus string `yaml:"reviewStatus"`
	ReviewedBy   string `yaml:"reviewedBy,omitempty"`
	ReviewedAt   string `yaml:"reviewedAt,omitempty"`
}

// IngestFromARTG ingests a drug from its ARTG ID.
// Note: TGA does not provide a public API. This would require:
// 1. Manual PDF download from TGA website
// 2. PDF parsing to extract text
// 3. Section identification and extraction
func (p *TGAIngestionPipeline) IngestFromARTG(ctx context.Context, artgID string) (*TGADosingExtract, error) {
	// TGA PI documents are PDFs and require manual or semi-automated extraction.
	// This is a placeholder for the actual implementation.
	
	return nil, fmt.Errorf("TGA ingestion requires PDF parsing - not yet implemented")
}

// =============================================================================
// CDSCO PACKAGE INSERT INGESTION
// =============================================================================

// CDSCOIngestionPipeline ingests drug labels from CDSCO.
type CDSCOIngestionPipeline struct {
	outputDir  string
	httpClient *http.Client
}

// NewCDSCOIngestionPipeline creates a new CDSCO ingestion pipeline.
func NewCDSCOIngestionPipeline(outputDir string) *CDSCOIngestionPipeline {
	return &CDSCOIngestionPipeline{
		outputDir:  outputDir,
		httpClient: &http.Client{Timeout: 60 * time.Second},
	}
}

// CDSCODosingExtract represents extracted dosing from CDSCO package insert.
type CDSCODosingExtract struct {
	DrugName      string    `yaml:"drugName"`
	Manufacturer  string    `yaml:"manufacturer"`
	ExtractedAt   time.Time `yaml:"extractedAt"`
	
	// Content sections
	DoseAndAdmin       string `yaml:"doseAndAdmin"`
	Contraindications  string `yaml:"contraindications"`
	Warnings           string `yaml:"warnings"`
	SpecialPrecautions string `yaml:"specialPrecautions"`
	
	// India-specific
	NLEMStatus     bool     `yaml:"nlemStatus"`
	ScheduleStatus string   `yaml:"scheduleStatus"` // H, H1, X, etc.
	DPCOPrice      float64  `yaml:"dpcoPrice,omitempty"`
	BrandNames     []string `yaml:"brandNames,omitempty"`
	
	// Review status
	ReviewStatus string `yaml:"reviewStatus"`
}

// =============================================================================
// COMPENDIA INTEGRATION INTERFACE
// =============================================================================

// CompendiumAdapter defines the interface for integrating commercial compendia.
// This allows KB-1 to ingest data from Lexicomp, Micromedex, BNF, AMH, NFI
// when licenses are obtained.
type CompendiumAdapter interface {
	// GetName returns the compendium name
	GetName() string
	
	// GetAuthority returns the authority constant
	GetAuthority() Authority
	
	// Search searches for a drug by name or code
	Search(ctx context.Context, query string) ([]CompendiumDrug, error)
	
	// GetDosingByRxNorm retrieves dosing information by RxNorm code
	GetDosingByRxNorm(ctx context.Context, rxnormCode string) (*CompendiumDosing, error)
	
	// GetInteractions retrieves drug interactions
	GetInteractions(ctx context.Context, rxnormCode string) ([]CompendiumInteraction, error)
	
	// GetMonitoring retrieves monitoring parameters
	GetMonitoring(ctx context.Context, rxnormCode string) ([]string, error)
}

// CompendiumDrug represents a drug from a compendium.
type CompendiumDrug struct {
	ID          string   `json:"id"`
	Name        string   `json:"name"`
	GenericName string   `json:"genericName"`
	RxNormCodes []string `json:"rxnormCodes"`
}

// CompendiumDosing represents dosing from a compendium.
type CompendiumDosing struct {
	Source      string              `json:"source"`
	LastUpdated time.Time           `json:"lastUpdated"`
	Adult       *CompendiumAdultDose `json:"adult,omitempty"`
	Pediatric   *CompendiumPedDose   `json:"pediatric,omitempty"`
	Renal       []CompendiumRenalAdj `json:"renal,omitempty"`
	Hepatic     []CompendiumHepAdj   `json:"hepatic,omitempty"`
	MaxDoses    *CompendiumMaxDoses  `json:"maxDoses,omitempty"`
}

// CompendiumAdultDose represents adult dosing from a compendium.
type CompendiumAdultDose struct {
	Indications []CompendiumIndication `json:"indications"`
}

// CompendiumIndication represents indication-specific dosing.
type CompendiumIndication struct {
	Name     string  `json:"name"`
	Dose     string  `json:"dose"`
	Route    string  `json:"route"`
	Frequency string `json:"frequency"`
	Duration string  `json:"duration,omitempty"`
	Notes    string  `json:"notes,omitempty"`
}

// CompendiumPedDose represents pediatric dosing from a compendium.
type CompendiumPedDose struct {
	AgeRanges []CompendiumAgeRange `json:"ageRanges"`
}

// CompendiumAgeRange represents age-specific pediatric dosing.
type CompendiumAgeRange struct {
	MinAge    string `json:"minAge"`
	MaxAge    string `json:"maxAge"`
	Dose      string `json:"dose"`
	MaxDose   string `json:"maxDose,omitempty"`
	Notes     string `json:"notes,omitempty"`
}

// CompendiumRenalAdj represents renal adjustment from a compendium.
type CompendiumRenalAdj struct {
	CrClRange  string `json:"crclRange"`
	Adjustment string `json:"adjustment"`
	Notes      string `json:"notes,omitempty"`
}

// CompendiumHepAdj represents hepatic adjustment from a compendium.
type CompendiumHepAdj struct {
	Severity   string `json:"severity"` // Mild, Moderate, Severe, Child-Pugh A/B/C
	Adjustment string `json:"adjustment"`
	Notes      string `json:"notes,omitempty"`
}

// CompendiumMaxDoses represents maximum dose limits.
type CompendiumMaxDoses struct {
	MaxSingle string `json:"maxSingle,omitempty"`
	MaxDaily  string `json:"maxDaily,omitempty"`
	Notes     string `json:"notes,omitempty"`
}

// CompendiumInteraction represents a drug interaction.
type CompendiumInteraction struct {
	Drug        string `json:"drug"`
	RxNormCode  string `json:"rxnormCode,omitempty"`
	Severity    string `json:"severity"` // Major, Moderate, Minor
	Effect      string `json:"effect"`
	Mechanism   string `json:"mechanism,omitempty"`
	Management  string `json:"management,omitempty"`
}

// =============================================================================
// PLACEHOLDER ADAPTERS (For future implementation when licensed)
// =============================================================================

// LexicompAdapter is a placeholder for Lexicomp integration.
type LexicompAdapter struct {
	apiKey    string
	baseURL   string
}

func (a *LexicompAdapter) GetName() string { return "Lexicomp" }
func (a *LexicompAdapter) GetAuthority() Authority { return AuthorityLexicomp }
func (a *LexicompAdapter) Search(ctx context.Context, query string) ([]CompendiumDrug, error) {
	return nil, fmt.Errorf("Lexicomp integration not yet licensed")
}
func (a *LexicompAdapter) GetDosingByRxNorm(ctx context.Context, rxnormCode string) (*CompendiumDosing, error) {
	return nil, fmt.Errorf("Lexicomp integration not yet licensed")
}
func (a *LexicompAdapter) GetInteractions(ctx context.Context, rxnormCode string) ([]CompendiumInteraction, error) {
	return nil, fmt.Errorf("Lexicomp integration not yet licensed")
}
func (a *LexicompAdapter) GetMonitoring(ctx context.Context, rxnormCode string) ([]string, error) {
	return nil, fmt.Errorf("Lexicomp integration not yet licensed")
}

// AMHAdapter is a placeholder for Australian Medicines Handbook integration.
type AMHAdapter struct {
	apiKey  string
	baseURL string
}

func (a *AMHAdapter) GetName() string { return "Australian Medicines Handbook" }
func (a *AMHAdapter) GetAuthority() Authority { return AuthorityAMH }
func (a *AMHAdapter) Search(ctx context.Context, query string) ([]CompendiumDrug, error) {
	return nil, fmt.Errorf("AMH integration not yet licensed")
}
func (a *AMHAdapter) GetDosingByRxNorm(ctx context.Context, rxnormCode string) (*CompendiumDosing, error) {
	return nil, fmt.Errorf("AMH integration not yet licensed")
}
func (a *AMHAdapter) GetInteractions(ctx context.Context, rxnormCode string) ([]CompendiumInteraction, error) {
	return nil, fmt.Errorf("AMH integration not yet licensed")
}
func (a *AMHAdapter) GetMonitoring(ctx context.Context, rxnormCode string) ([]string, error) {
	return nil, fmt.Errorf("AMH integration not yet licensed")
}

// NFIAdapter is a placeholder for National Formulary of India integration.
type NFIAdapter struct {
	// NFI doesn't have an API; would require PDF parsing
}

func (a *NFIAdapter) GetName() string { return "National Formulary of India" }
func (a *NFIAdapter) GetAuthority() Authority { return AuthorityNFI }
func (a *NFIAdapter) Search(ctx context.Context, query string) ([]CompendiumDrug, error) {
	return nil, fmt.Errorf("NFI integration not yet implemented")
}
func (a *NFIAdapter) GetDosingByRxNorm(ctx context.Context, rxnormCode string) (*CompendiumDosing, error) {
	return nil, fmt.Errorf("NFI integration not yet implemented")
}
func (a *NFIAdapter) GetInteractions(ctx context.Context, rxnormCode string) ([]CompendiumInteraction, error) {
	return nil, fmt.Errorf("NFI integration not yet implemented")
}
func (a *NFIAdapter) GetMonitoring(ctx context.Context, rxnormCode string) ([]string, error) {
	return nil, fmt.Errorf("NFI integration not yet implemented")
}

// =============================================================================
// AUTHORITY TYPE (matching governance package)
// =============================================================================

type Authority string

const (
	AuthorityFDA       Authority = "FDA"
	AuthorityTGA       Authority = "TGA"
	AuthorityCDSCO     Authority = "CDSCO"
	AuthorityLexicomp  Authority = "LEXICOMP"
	AuthorityMicromedex Authority = "MICROMEDEX"
	AuthorityBNF       Authority = "BNF"
	AuthorityAMH       Authority = "AMH"
	AuthorityNFI       Authority = "NFI"
)

// Package governance implements the governed drug dosing rule system for KB-1.
// This replaces hardcoded rules with jurisdiction-aware, regulator-anchored YAML rules.
package governance

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"time"

	"gopkg.in/yaml.v3"
)

// =============================================================================
// GOVERNANCE TYPES
// =============================================================================

// Authority represents a regulatory or clinical authority.
type Authority string

const (
	AuthorityFDA       Authority = "FDA"
	AuthorityTGA       Authority = "TGA"
	AuthorityCDSCO     Authority = "CDSCO"
	AuthorityEMA       Authority = "EMA"
	AuthorityMHRA      Authority = "MHRA"
	AuthorityNICE      Authority = "NICE"
	AuthorityWHO       Authority = "WHO"
	AuthorityIDSA      Authority = "IDSA"
	AuthorityACCP      Authority = "ACCP"
	AuthorityACC_AHA   Authority = "ACC_AHA"
	AuthorityADA       Authority = "ADA"
	AuthorityKDIGO     Authority = "KDIGO"
	AuthorityNCCN      Authority = "NCCN"
	AuthorityLexicomp  Authority = "LEXICOMP"
	AuthorityMicromedex Authority = "MICROMEDEX"
	AuthorityBNF       Authority = "BNF"
	AuthorityAMH       Authority = "AMH"
	AuthorityNFI       Authority = "NFI"
	AuthorityInternal  Authority = "INTERNAL"
)

// Jurisdiction represents where rules apply.
type Jurisdiction string

const (
	JurisdictionUS     Jurisdiction = "US"
	JurisdictionAU     Jurisdiction = "AU"
	JurisdictionIN     Jurisdiction = "IN"
	JurisdictionUK     Jurisdiction = "UK"
	JurisdictionEU     Jurisdiction = "EU"
	JurisdictionGlobal Jurisdiction = "GLOBAL"
)

// EvidenceLevel represents the strength of evidence.
type EvidenceLevel string

const (
	EvidenceLevelA      EvidenceLevel = "A"
	EvidenceLevelB      EvidenceLevel = "B"
	EvidenceLevelC      EvidenceLevel = "C"
	EvidenceLevelD      EvidenceLevel = "D"
	EvidenceLevelExpert EvidenceLevel = "EXPERT"
	EvidenceLevelLabel  EvidenceLevel = "LABEL"
)

// =============================================================================
// GOVERNED DRUG DOSING RULE
// =============================================================================

// GovernedDosingRule represents a fully governed drug dosing rule.
type GovernedDosingRule struct {
	Drug       DrugInfo       `yaml:"drug"`
	Dosing     DosingInfo     `yaml:"dosing"`
	Safety     SafetyInfo     `yaml:"safety"`
	Governance GovernanceInfo `yaml:"governance"`
}

// DrugInfo contains drug identification information.
type DrugInfo struct {
	RxNormCode   string       `yaml:"rxnormCode"`
	Name         string       `yaml:"name"`
	GenericName  string       `yaml:"genericName"`
	DrugClass    string       `yaml:"drugClass"`
	ATCCode      string       `yaml:"atcCode,omitempty"`
	SNOMEDCode   string       `yaml:"snomedCode,omitempty"`
	AMTCode      string       `yaml:"amtCode,omitempty"`
	IndiaBrands  []IndiaBrand `yaml:"indiaBrands,omitempty"`
}

// IndiaBrand represents India-specific brand mapping.
type IndiaBrand struct {
	BrandName    string   `yaml:"brandName"`
	Manufacturer string   `yaml:"manufacturer"`
	Strengths    []string `yaml:"strengths"`
	NLEMListed   bool     `yaml:"nlemListed"`
	JanAushadhi  bool     `yaml:"janAushadhi,omitempty"`
	Price        float64  `yaml:"price,omitempty"`
}

// DosingInfo contains all dosing information.
type DosingInfo struct {
	PrimaryMethod string             `yaml:"primaryMethod"`
	Adult         *AdultDosing       `yaml:"adult,omitempty"`
	WeightBased   *WeightBasedDosing `yaml:"weightBased,omitempty"`
	BSABased      *BSABasedDosing    `yaml:"bsaBased,omitempty"`
	Pediatric     *PediatricDosing   `yaml:"pediatric,omitempty"`
	Geriatric     *GeriatricDosing   `yaml:"geriatric,omitempty"`
	Renal         *RenalDosing       `yaml:"renal,omitempty"`
	Hepatic       *HepaticDosing     `yaml:"hepatic,omitempty"`
	Titration     *TitrationSchedule `yaml:"titration,omitempty"`
}

// AdultDosing contains adult dosing information.
type AdultDosing struct {
	Standard  []StandardDose `yaml:"standard"`
	MaxDaily  float64        `yaml:"maxDaily"`
	MaxSingle float64        `yaml:"maxSingle"`
	MaxUnit   string         `yaml:"maxUnit"`
}

// StandardDose represents a standard dose entry.
type StandardDose struct {
	Indication        string     `yaml:"indication"`
	Route             string     `yaml:"route"`
	Dose              float64    `yaml:"dose,omitempty"`
	DoseRange         *DoseRange `yaml:"doseRange,omitempty"`
	Unit              string     `yaml:"unit"`
	Frequency         string     `yaml:"frequency"`
	IsStartingDose    bool       `yaml:"isStartingDose,omitempty"`
	IsMaintenanceDose bool       `yaml:"isMaintenanceDose,omitempty"`
	Notes             string     `yaml:"notes,omitempty"`
}

// DoseRange represents a dose range.
type DoseRange struct {
	Min float64 `yaml:"min"`
	Max float64 `yaml:"max"`
}

// WeightBasedDosing contains weight-based dosing parameters.
type WeightBasedDosing struct {
	DosePerKg         float64 `yaml:"dosePerKg"`
	Unit              string  `yaml:"unit"`
	Frequency         string  `yaml:"frequency"`
	MinDose           float64 `yaml:"minDose,omitempty"`
	MaxDose           float64 `yaml:"maxDose,omitempty"`
	UseIdealWeight    bool    `yaml:"useIdealWeight,omitempty"`
	UseAdjustedWeight bool    `yaml:"useAdjustedWeight,omitempty"`
	Notes             string  `yaml:"notes,omitempty"`
}

// BSABasedDosing contains BSA-based dosing parameters.
type BSABasedDosing struct {
	DosePerM2       float64 `yaml:"dosePerM2"`
	Unit            string  `yaml:"unit"`
	MaxAbsoluteDose float64 `yaml:"maxAbsoluteDose,omitempty"`
	CappedAtBSA     float64 `yaml:"cappedAtBSA,omitempty"`
	Notes           string  `yaml:"notes,omitempty"`
}

// PediatricDosing contains pediatric dosing information.
type PediatricDosing struct {
	AgeRanges       []PediatricAgeRange `yaml:"ageRanges"`
	UseWeight       bool                `yaml:"useWeight"`
	MinAge          int                 `yaml:"minAge,omitempty"`
	Contraindicated bool                `yaml:"contraindicated,omitempty"`
	Notes           string              `yaml:"notes,omitempty"`
}

// PediatricAgeRange represents dosing for a specific age group.
type PediatricAgeRange struct {
	AgeGroup      string  `yaml:"ageGroup"`
	MinAgeMonths  int     `yaml:"minAgeMonths"`
	MaxAgeMonths  int     `yaml:"maxAgeMonths"`
	DosePerKg     float64 `yaml:"dosePerKg,omitempty"`
	Unit          string  `yaml:"unit"`
	Frequency     string  `yaml:"frequency"`
	MaxDose       float64 `yaml:"maxDose,omitempty"`
}

// GeriatricDosing contains geriatric-specific adjustments.
type GeriatricDosing struct {
	StartLow        bool    `yaml:"startLow"`
	DoseReduction   float64 `yaml:"doseReduction,omitempty"`
	AvoidInElderly  bool    `yaml:"avoidInElderly,omitempty"`
	BeersListStatus string  `yaml:"beersListStatus,omitempty"`
	Notes           string  `yaml:"notes,omitempty"`
}

// RenalDosing contains renal adjustment information.
type RenalDosing struct {
	AdjustmentBasis string            `yaml:"adjustmentBasis"`
	Adjustments     []RenalAdjustment `yaml:"adjustments"`
	Notes           string            `yaml:"notes,omitempty"`
}

// RenalAdjustment represents a specific renal adjustment tier.
type RenalAdjustment struct {
	MinCrCl        float64 `yaml:"minCrCl"`
	MaxCrCl        float64 `yaml:"maxCrCl"`
	DosePercent    float64 `yaml:"dosePercent,omitempty"`
	Frequency      string  `yaml:"frequency,omitempty"`
	Avoid          bool    `yaml:"avoid,omitempty"`
	Dialyzable     bool    `yaml:"dialyzable,omitempty"`
	SupplementDose float64 `yaml:"supplementDose,omitempty"`
	Notes          string  `yaml:"notes,omitempty"`
}

// HepaticDosing contains hepatic adjustment information.
type HepaticDosing struct {
	ChildPughA *HepaticAdjustment `yaml:"childPughA,omitempty"`
	ChildPughB *HepaticAdjustment `yaml:"childPughB,omitempty"`
	ChildPughC *HepaticAdjustment `yaml:"childPughC,omitempty"`
	Notes      string             `yaml:"notes,omitempty"`
}

// HepaticAdjustment represents a hepatic adjustment.
type HepaticAdjustment struct {
	DosePercent float64 `yaml:"dosePercent,omitempty"`
	FixedDose   float64 `yaml:"fixedDose,omitempty"`
	Avoid       bool    `yaml:"avoid,omitempty"`
	Notes       string  `yaml:"notes,omitempty"`
}

// TitrationSchedule represents a dose titration plan.
type TitrationSchedule struct {
	Steps   []TitrationStep `yaml:"steps"`
	Target  string          `yaml:"target,omitempty"`
	MaxDose float64         `yaml:"maxDose,omitempty"`
	Notes   string          `yaml:"notes,omitempty"`
}

// TitrationStep represents a single titration step.
type TitrationStep struct {
	StepNumber   int     `yaml:"stepNumber"`
	Dose         float64 `yaml:"dose"`
	Unit         string  `yaml:"unit"`
	Frequency    string  `yaml:"frequency"`
	DurationDays int     `yaml:"durationDays,omitempty"`
	Criteria     string  `yaml:"criteria,omitempty"`
	Notes        string  `yaml:"notes,omitempty"`
}

// SafetyInfo contains safety and warning information.
type SafetyInfo struct {
	HighAlertDrug          bool     `yaml:"highAlertDrug"`
	NarrowTherapeuticIndex bool     `yaml:"narrowTherapeuticIndex"`
	BlackBoxWarning        bool     `yaml:"blackBoxWarning"`
	BlackBoxText           string   `yaml:"blackBoxText,omitempty"`
	Monitoring             []string `yaml:"monitoring,omitempty"`
	Contraindications      []string `yaml:"contraindications,omitempty"`
	MajorInteractions      []string `yaml:"majorInteractions,omitempty"`
	ClinicalNotes          string   `yaml:"clinicalNotes,omitempty"`
}

// GovernanceInfo contains regulatory and approval metadata.
type GovernanceInfo struct {
	Authority        Authority       `yaml:"authority"`
	Document         string          `yaml:"document"`
	Section          string          `yaml:"section,omitempty"`
	URL              string          `yaml:"url,omitempty"`
	Jurisdiction     Jurisdiction    `yaml:"jurisdiction"`
	EvidenceLevel    EvidenceLevel   `yaml:"evidenceLevel,omitempty"`
	EffectiveDate    string          `yaml:"effectiveDate,omitempty"`
	ExpirationDate   string          `yaml:"expirationDate,omitempty"`
	Version          string          `yaml:"version"`
	ApprovedBy       string          `yaml:"approvedBy"`
	ApprovedAt       string          `yaml:"approvedAt"`
	LastReviewedAt   string          `yaml:"lastReviewedAt,omitempty"`
	LastReviewedBy   string          `yaml:"lastReviewedBy,omitempty"`
	NextReviewDue    string          `yaml:"nextReviewDue,omitempty"`
	ChangeLog        []ChangeLogEntry `yaml:"changeLog,omitempty"`
	SecondarySources []SecondarySource `yaml:"secondarySources,omitempty"`
}

// ChangeLogEntry represents a change in the rule history.
type ChangeLogEntry struct {
	Date     string `yaml:"date"`
	Change   string `yaml:"change"`
	Reviewer string `yaml:"reviewer"`
}

// SecondarySource represents an additional reference source.
type SecondarySource struct {
	Authority Authority `yaml:"authority"`
	Document  string    `yaml:"document"`
	Section   string    `yaml:"section,omitempty"`
	Reason    string    `yaml:"reason,omitempty"`
}

// =============================================================================
// GOVERNED RULE LOADER
// =============================================================================

// GovernedRuleLoader loads governed drug dosing rules from YAML files.
type GovernedRuleLoader struct {
	knowledgeDir string
	
	// Cache: [jurisdiction][rxnormCode] -> GovernedDosingRule
	rules     map[Jurisdiction]map[string]*GovernedDosingRule
	rulesMu   sync.RWMutex
	
	// Index: [rxnormCode] -> []Jurisdiction (which jurisdictions have this drug)
	drugIndex map[string][]Jurisdiction
	indexMu   sync.RWMutex
	
	// Metrics
	loadedAt  time.Time
	ruleCount int
}

// NewGovernedRuleLoader creates a new loader.
func NewGovernedRuleLoader(knowledgeDir string) *GovernedRuleLoader {
	return &GovernedRuleLoader{
		knowledgeDir: knowledgeDir,
		rules:        make(map[Jurisdiction]map[string]*GovernedDosingRule),
		drugIndex:    make(map[string][]Jurisdiction),
	}
}

// LoadAll loads all governed rules from the knowledge directory.
func (l *GovernedRuleLoader) LoadAll(ctx context.Context) error {
	l.rulesMu.Lock()
	defer l.rulesMu.Unlock()
	
	l.indexMu.Lock()
	defer l.indexMu.Unlock()
	
	// Reset
	l.rules = make(map[Jurisdiction]map[string]*GovernedDosingRule)
	l.drugIndex = make(map[string][]Jurisdiction)
	l.ruleCount = 0
	
	// Load each jurisdiction
	jurisdictions := []Jurisdiction{
		JurisdictionUS,
		JurisdictionAU,
		JurisdictionIN,
		JurisdictionUK,
		JurisdictionEU,
		JurisdictionGlobal,
	}
	
	for _, jur := range jurisdictions {
		jurDir := filepath.Join(l.knowledgeDir, string(jur))
		if _, err := os.Stat(jurDir); os.IsNotExist(err) {
			continue // Jurisdiction directory doesn't exist, skip
		}
		
		l.rules[jur] = make(map[string]*GovernedDosingRule)
		
		err := filepath.Walk(jurDir, func(path string, info os.FileInfo, err error) error {
			if err != nil {
				return err
			}
			
			if info.IsDir() || filepath.Ext(path) != ".yaml" {
				return nil
			}
			
			rule, err := l.loadRuleFile(path)
			if err != nil {
				return fmt.Errorf("failed to load %s: %w", path, err)
			}
			
			// Index by RxNorm code
			rxnorm := rule.Drug.RxNormCode
			l.rules[jur][rxnorm] = rule
			l.drugIndex[rxnorm] = append(l.drugIndex[rxnorm], jur)
			l.ruleCount++
			
			return nil
		})
		
		if err != nil {
			return fmt.Errorf("failed to load jurisdiction %s: %w", jur, err)
		}
	}
	
	l.loadedAt = time.Now()
	return nil
}

// loadRuleFile loads a single YAML rule file.
func (l *GovernedRuleLoader) loadRuleFile(path string) (*GovernedDosingRule, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	
	var rule GovernedDosingRule
	if err := yaml.Unmarshal(data, &rule); err != nil {
		return nil, fmt.Errorf("YAML parse error: %w", err)
	}
	
	// Validate required governance fields
	if err := l.validateGovernance(&rule); err != nil {
		return nil, fmt.Errorf("governance validation failed: %w", err)
	}
	
	return &rule, nil
}

// validateGovernance ensures governance fields are complete.
func (l *GovernedRuleLoader) validateGovernance(rule *GovernedDosingRule) error {
	gov := rule.Governance
	
	if gov.Authority == "" {
		return fmt.Errorf("authority is required")
	}
	if gov.Document == "" {
		return fmt.Errorf("document is required")
	}
	if gov.Jurisdiction == "" {
		return fmt.Errorf("jurisdiction is required")
	}
	if gov.Version == "" {
		return fmt.Errorf("version is required")
	}
	if gov.ApprovedBy == "" {
		return fmt.Errorf("approvedBy is required")
	}
	if gov.ApprovedAt == "" {
		return fmt.Errorf("approvedAt is required")
	}
	
	return nil
}

// GetRule retrieves a rule for a specific drug and jurisdiction.
func (l *GovernedRuleLoader) GetRule(rxnormCode string, jurisdiction Jurisdiction) (*GovernedDosingRule, error) {
	l.rulesMu.RLock()
	defer l.rulesMu.RUnlock()
	
	jurRules, exists := l.rules[jurisdiction]
	if !exists {
		return nil, fmt.Errorf("no rules loaded for jurisdiction %s", jurisdiction)
	}
	
	rule, exists := jurRules[rxnormCode]
	if !exists {
		return nil, fmt.Errorf("no rule for RxNorm %s in jurisdiction %s", rxnormCode, jurisdiction)
	}
	
	return rule, nil
}

// GetRuleWithFallback tries to get a rule for the specified jurisdiction,
// falling back to GLOBAL if not found.
func (l *GovernedRuleLoader) GetRuleWithFallback(rxnormCode string, jurisdiction Jurisdiction) (*GovernedDosingRule, error) {
	// Try requested jurisdiction first
	rule, err := l.GetRule(rxnormCode, jurisdiction)
	if err == nil {
		return rule, nil
	}
	
	// Fallback to GLOBAL
	if jurisdiction != JurisdictionGlobal {
		rule, err = l.GetRule(rxnormCode, JurisdictionGlobal)
		if err == nil {
			return rule, nil
		}
	}
	
	return nil, fmt.Errorf("no rule for RxNorm %s in jurisdiction %s or GLOBAL", rxnormCode, jurisdiction)
}

// GetAvailableJurisdictions returns jurisdictions that have rules for a drug.
func (l *GovernedRuleLoader) GetAvailableJurisdictions(rxnormCode string) []Jurisdiction {
	l.indexMu.RLock()
	defer l.indexMu.RUnlock()
	
	return l.drugIndex[rxnormCode]
}

// GetStats returns loader statistics.
func (l *GovernedRuleLoader) GetStats() map[string]interface{} {
	l.rulesMu.RLock()
	defer l.rulesMu.RUnlock()
	
	jurCounts := make(map[string]int)
	for jur, rules := range l.rules {
		jurCounts[string(jur)] = len(rules)
	}
	
	return map[string]interface{}{
		"total_rules":        l.ruleCount,
		"loaded_at":          l.loadedAt,
		"jurisdiction_counts": jurCounts,
	}
}

// =============================================================================
// DOSE CALCULATION WITH GOVERNANCE
// =============================================================================

// GovernedDoseResult represents a dose calculation result with full provenance.
type GovernedDoseResult struct {
	// Calculated dose
	Dose      float64 `json:"dose"`
	Unit      string  `json:"unit"`
	Frequency string  `json:"frequency"`
	MaxDaily  float64 `json:"maxDaily,omitempty"`
	
	// Adjustments applied
	Adjustments []string `json:"adjustments,omitempty"`
	
	// Warnings
	Warnings []string `json:"warnings,omitempty"`
	
	// Governance provenance (CRITICAL)
	Source GovernanceProvenance `json:"source"`
}

// GovernanceProvenance provides regulatory traceability.
type GovernanceProvenance struct {
	Authority    Authority    `json:"authority"`
	Document     string       `json:"document"`
	Section      string       `json:"section,omitempty"`
	URL          string       `json:"url,omitempty"`
	Jurisdiction Jurisdiction `json:"jurisdiction"`
	Version      string       `json:"version"`
	ApprovedBy   string       `json:"approvedBy"`
	ApprovedAt   string       `json:"approvedAt"`
}

// CalculateGovernedDose calculates a dose using governed rules.
func (l *GovernedRuleLoader) CalculateGovernedDose(
	ctx context.Context,
	rxnormCode string,
	jurisdiction Jurisdiction,
	patientAge int,
	patientWeightKg float64,
	eGFR float64,
	childPugh string,
) (*GovernedDoseResult, error) {
	
	// Get the governed rule
	rule, err := l.GetRuleWithFallback(rxnormCode, jurisdiction)
	if err != nil {
		return nil, err
	}
	
	result := &GovernedDoseResult{
		Adjustments: []string{},
		Warnings:    []string{},
	}
	
	// Build provenance from governance
	result.Source = GovernanceProvenance{
		Authority:    rule.Governance.Authority,
		Document:     rule.Governance.Document,
		Section:      rule.Governance.Section,
		URL:          rule.Governance.URL,
		Jurisdiction: rule.Governance.Jurisdiction,
		Version:      rule.Governance.Version,
		ApprovedBy:   rule.Governance.ApprovedBy,
		ApprovedAt:   rule.Governance.ApprovedAt,
	}
	
	// Get base adult dose
	if rule.Dosing.Adult != nil && len(rule.Dosing.Adult.Standard) > 0 {
		// Find starting dose
		for _, sd := range rule.Dosing.Adult.Standard {
			if sd.IsStartingDose {
				result.Dose = sd.Dose
				result.Unit = sd.Unit
				result.Frequency = sd.Frequency
				break
			}
		}
		// Fallback to first dose if no starting dose marked
		if result.Dose == 0 {
			sd := rule.Dosing.Adult.Standard[0]
			result.Dose = sd.Dose
			result.Unit = sd.Unit
			result.Frequency = sd.Frequency
		}
		result.MaxDaily = rule.Dosing.Adult.MaxDaily
	}
	
	// Apply renal adjustment
	if rule.Dosing.Renal != nil && eGFR > 0 {
		for _, adj := range rule.Dosing.Renal.Adjustments {
			if eGFR >= adj.MinCrCl && eGFR < adj.MaxCrCl {
				if adj.Avoid {
					result.Warnings = append(result.Warnings, 
						fmt.Sprintf("Contraindicated: eGFR %.0f - %s", eGFR, adj.Notes))
				} else if adj.DosePercent > 0 && adj.DosePercent < 100 {
					result.Dose = result.Dose * (adj.DosePercent / 100)
					result.Adjustments = append(result.Adjustments,
						fmt.Sprintf("Renal adjustment: %.0f%% (eGFR %.0f)", adj.DosePercent, eGFR))
				}
				if adj.Frequency != "" {
					result.Frequency = adj.Frequency
					result.Adjustments = append(result.Adjustments,
						fmt.Sprintf("Frequency adjusted to %s for renal function", adj.Frequency))
				}
				break
			}
		}
	}
	
	// Apply geriatric adjustment
	if patientAge >= 65 && rule.Dosing.Geriatric != nil {
		ger := rule.Dosing.Geriatric
		if ger.AvoidInElderly {
			result.Warnings = append(result.Warnings,
				fmt.Sprintf("Beers List: %s", ger.BeersListStatus))
		}
		if ger.StartLow && ger.DoseReduction > 0 {
			result.Dose = result.Dose * ((100 - ger.DoseReduction) / 100)
			result.Adjustments = append(result.Adjustments,
				fmt.Sprintf("Geriatric reduction: %.0f%%", ger.DoseReduction))
		}
	}
	
	// Apply hepatic adjustment
	if childPugh != "" && rule.Dosing.Hepatic != nil {
		var hepAdj *HepaticAdjustment
		switch childPugh {
		case "A":
			hepAdj = rule.Dosing.Hepatic.ChildPughA
		case "B":
			hepAdj = rule.Dosing.Hepatic.ChildPughB
		case "C":
			hepAdj = rule.Dosing.Hepatic.ChildPughC
		}
		if hepAdj != nil {
			if hepAdj.Avoid {
				result.Warnings = append(result.Warnings,
					fmt.Sprintf("Contraindicated in Child-Pugh %s: %s", childPugh, hepAdj.Notes))
			} else if hepAdj.DosePercent > 0 {
				result.Dose = result.Dose * (hepAdj.DosePercent / 100)
				result.Adjustments = append(result.Adjustments,
					fmt.Sprintf("Hepatic adjustment (Child-Pugh %s): %.0f%%", childPugh, hepAdj.DosePercent))
			}
		}
	}
	
	// Add safety warnings
	if rule.Safety.HighAlertDrug {
		result.Warnings = append(result.Warnings, "HIGH-ALERT MEDICATION")
	}
	if rule.Safety.BlackBoxWarning {
		result.Warnings = append(result.Warnings,
			fmt.Sprintf("BLACK BOX WARNING: %s", rule.Safety.BlackBoxText))
	}
	
	return result, nil
}

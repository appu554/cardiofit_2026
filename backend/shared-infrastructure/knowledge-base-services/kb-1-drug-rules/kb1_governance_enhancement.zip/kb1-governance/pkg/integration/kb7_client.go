// Package integration provides KB-1 to KB-7 integration for terminology validation.
// This ensures that drug codes are validated against the authoritative terminology service.
package integration

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"time"
)

// =============================================================================
// KB-7 CLIENT
// =============================================================================

// KB7Client provides integration with KB-7 Terminology Service.
type KB7Client struct {
	baseURL    string
	httpClient *http.Client
}

// NewKB7Client creates a new KB-7 client.
func NewKB7Client(baseURL string) *KB7Client {
	return &KB7Client{
		baseURL: baseURL,
		httpClient: &http.Client{
			Timeout: 10 * time.Second,
		},
	}
}

// =============================================================================
// RXNORM VALIDATION
// =============================================================================

// ValidateRxNormCode validates that an RxNorm code exists in KB-7.
func (c *KB7Client) ValidateRxNormCode(ctx context.Context, rxnormCode string) (*RxNormValidation, error) {
	url := fmt.Sprintf("%s/v1/concepts/%s", c.baseURL, rxnormCode)
	
	req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
	if err != nil {
		return nil, err
	}
	
	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("KB-7 request failed: %w", err)
	}
	defer resp.Body.Close()
	
	if resp.StatusCode == http.StatusNotFound {
		return &RxNormValidation{
			Valid:   false,
			Code:    rxnormCode,
			Message: "RxNorm code not found in KB-7",
		}, nil
	}
	
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("KB-7 returned status %d", resp.StatusCode)
	}
	
	var concept KB7Concept
	if err := json.NewDecoder(resp.Body).Decode(&concept); err != nil {
		return nil, err
	}
	
	return &RxNormValidation{
		Valid:       true,
		Code:        rxnormCode,
		Name:        concept.Label,
		Terminology: "RxNorm",
	}, nil
}

// RxNormValidation represents the result of RxNorm validation.
type RxNormValidation struct {
	Valid       bool   `json:"valid"`
	Code        string `json:"code"`
	Name        string `json:"name,omitempty"`
	Terminology string `json:"terminology,omitempty"`
	Message     string `json:"message,omitempty"`
}

// KB7Concept represents a concept from KB-7.
type KB7Concept struct {
	URI         string   `json:"uri"`
	Code        string   `json:"code"`
	Label       string   `json:"label"`
	Terminology string   `json:"terminology"`
	Parents     []string `json:"parents,omitempty"`
}

// =============================================================================
// SNOMED CT SUBSUMPTION
// =============================================================================

// CheckSubsumption checks if one SNOMED code subsumes another.
// Used for drug class membership (e.g., is Amoxicillin a Penicillin?).
func (c *KB7Client) CheckSubsumption(ctx context.Context, candidateCode, ancestorCode string) (*SubsumptionResult, error) {
	url := fmt.Sprintf("%s/v1/subsumption/check?candidate=%s&ancestor=%s",
		c.baseURL, candidateCode, ancestorCode)
	
	req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
	if err != nil {
		return nil, err
	}
	
	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("KB-7 subsumption check failed: %w", err)
	}
	defer resp.Body.Close()
	
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("KB-7 returned status %d", resp.StatusCode)
	}
	
	var result SubsumptionResult
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, err
	}
	
	return &result, nil
}

// SubsumptionResult represents the result of a subsumption check.
type SubsumptionResult struct {
	Valid      bool   `json:"valid"`
	MatchType  string `json:"matchType"` // exact, subsumption, none
	PathLength int    `json:"pathLength,omitempty"`
	Source     string `json:"source"`
}

// =============================================================================
// REFSET MEMBERSHIP (AUSTRALIA)
// =============================================================================

// CheckRefsetMembership checks if a code is in a specific refset.
// Used for Australian Schedule 8, PBS, etc.
func (c *KB7Client) CheckRefsetMembership(ctx context.Context, conceptCode, refsetID string) (*RefsetMembership, error) {
	url := fmt.Sprintf("%s/v1/refsets/%s/contains/%s", c.baseURL, refsetID, conceptCode)
	
	req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
	if err != nil {
		return nil, err
	}
	
	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("KB-7 refset check failed: %w", err)
	}
	defer resp.Body.Close()
	
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("KB-7 returned status %d", resp.StatusCode)
	}
	
	var result RefsetMembership
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, err
	}
	
	return &result, nil
}

// RefsetMembership represents refset membership check result.
type RefsetMembership struct {
	IsMember   bool   `json:"isMember"`
	RefsetID   string `json:"refsetId"`
	RefsetName string `json:"refsetName,omitempty"`
	ConceptID  string `json:"conceptId"`
}

// Australian refset IDs for drug scheduling
const (
	RefsetSchedule8 = "1050951000168102" // Schedule 8 Controlled Medications
	RefsetSchedule4 = "1050711000168101" // Tasmanian Schedule 4 Monitored
)

// CheckSchedule8 checks if a drug is Schedule 8 controlled in Australia.
func (c *KB7Client) CheckSchedule8(ctx context.Context, snomedCode string) (bool, error) {
	result, err := c.CheckRefsetMembership(ctx, snomedCode, RefsetSchedule8)
	if err != nil {
		return false, err
	}
	return result.IsMember, nil
}

// =============================================================================
// INDIA BRAND MAPPING
// =============================================================================

// ResolveBrandToGeneric resolves an Indian brand name to generic drug.
// Uses KB-7's TradeProduct → MedicinalProduct mapping.
func (c *KB7Client) ResolveBrandToGeneric(ctx context.Context, brandName string) (*BrandResolution, error) {
	url := fmt.Sprintf("%s/v1/brands/search?q=%s", c.baseURL, url.QueryEscape(brandName))
	
	req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
	if err != nil {
		return nil, err
	}
	
	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("KB-7 brand search failed: %w", err)
	}
	defer resp.Body.Close()
	
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("KB-7 returned status %d", resp.StatusCode)
	}
	
	var results []BrandResolution
	if err := json.NewDecoder(resp.Body).Decode(&results); err != nil {
		return nil, err
	}
	
	if len(results) == 0 {
		return nil, fmt.Errorf("brand not found: %s", brandName)
	}
	
	return &results[0], nil
}

// BrandResolution represents the resolution of a brand to generic.
type BrandResolution struct {
	BrandName    string   `json:"brandName"`
	Manufacturer string   `json:"manufacturer"`
	GenericName  string   `json:"genericName"`
	RxNormCode   string   `json:"rxnormCode,omitempty"`
	SNOMEDCodes  []string `json:"snomedCodes,omitempty"`
	Ingredients  []string `json:"ingredients,omitempty"`
	IsFDC        bool     `json:"isFdc"` // Fixed Dose Combination
}

// =============================================================================
// KB-1 SERVICE INTEGRATION
// =============================================================================

// KB1WithKB7 wraps KB-1 dosing service with KB-7 validation.
type KB1WithKB7 struct {
	kb7Client *KB7Client
}

// NewKB1WithKB7 creates a new KB-1 service with KB-7 integration.
func NewKB1WithKB7(kb7BaseURL string) *KB1WithKB7 {
	return &KB1WithKB7{
		kb7Client: NewKB7Client(kb7BaseURL),
	}
}

// ValidateDosingRequest validates a dosing request against KB-7.
func (s *KB1WithKB7) ValidateDosingRequest(ctx context.Context, rxnormCode string, jurisdiction string) error {
	// Step 1: Validate RxNorm code exists
	validation, err := s.kb7Client.ValidateRxNormCode(ctx, rxnormCode)
	if err != nil {
		return fmt.Errorf("KB-7 validation failed: %w", err)
	}
	
	if !validation.Valid {
		return fmt.Errorf("invalid RxNorm code: %s", rxnormCode)
	}
	
	// Step 2: For Australia, check if additional SNOMED validation needed
	if jurisdiction == "AU" {
		// Could check AMT code mapping, Schedule 8 status, etc.
	}
	
	return nil
}

// EnrichDosingResponse enriches a dosing response with KB-7 data.
func (s *KB1WithKB7) EnrichDosingResponse(ctx context.Context, response *DosingResponse, jurisdiction string) error {
	// Add drug class from KB-7 subsumption
	// Add schedule status from KB-7 refsets (AU)
	// Add brand alternatives from KB-7 brand mapping (IN)
	
	if jurisdiction == "AU" {
		// Check if Schedule 8
		isS8, err := s.kb7Client.CheckSchedule8(ctx, response.SNOMEDCode)
		if err == nil && isS8 {
			response.Warnings = append(response.Warnings, "Schedule 8 Controlled Medication (Australia)")
		}
	}
	
	return nil
}

// DosingResponse represents an enriched dosing response.
type DosingResponse struct {
	RxNormCode   string   `json:"rxnormCode"`
	SNOMEDCode   string   `json:"snomedCode,omitempty"`
	DrugName     string   `json:"drugName"`
	Dose         float64  `json:"dose"`
	Unit         string   `json:"unit"`
	Frequency    string   `json:"frequency"`
	Warnings     []string `json:"warnings,omitempty"`
	Adjustments  []string `json:"adjustments,omitempty"`
	DrugClasses  []string `json:"drugClasses,omitempty"`
	Alternatives []string `json:"alternatives,omitempty"`
}

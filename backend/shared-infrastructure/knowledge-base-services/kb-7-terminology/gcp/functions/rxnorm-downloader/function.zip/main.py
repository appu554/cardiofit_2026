"""
RxNorm Downloader - GCP Cloud Function
Downloads RxNorm from NIH UMLS API and streams to Cloud Storage
"""

import os
import hashlib
import logging
import json
import zipfile
import io
from datetime import datetime
from google.cloud import storage
from google.cloud import secretmanager
import requests
import functions_framework

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@functions_framework.http
def download_rxnorm(request):
    """
    Cloud Function to download RxNorm from NIH UMLS API

    Args:
        request: Flask request object

    Returns:
        JSON response with download status and metadata
    """

    try:
        # Get configuration
        project_id = os.environ['PROJECT_ID']
        source_bucket = os.environ['SOURCE_BUCKET']
        environment = os.environ['ENVIRONMENT']
        secret_name = os.environ['SECRET_NAME']

        logger.info(f"Starting RxNorm download for environment: {environment}")

        # Retrieve UMLS API key from Secret Manager
        secret_client = secretmanager.SecretManagerServiceClient()
        secret_path = f"projects/{project_id}/secrets/{secret_name}/versions/latest"

        logger.info(f"Retrieving UMLS API key from Secret Manager")
        api_key_response = secret_client.access_secret_version(name=secret_path)
        umls_api_key = api_key_response.payload.data.decode('UTF-8')

        # Get RxNorm current version metadata
        logger.info("Fetching RxNorm version metadata from NIH UMLS")
        version_url = "https://rxnav.nlm.nih.gov/REST/version.json"
        version_response = requests.get(version_url, timeout=30)
        version_response.raise_for_status()

        version_data = version_response.json()
        version = version_data.get('version', datetime.now().strftime('%Y%m%d'))

        logger.info(f"RxNorm version: {version}")

        # UMLS download URL for RxNorm RRF files
        download_url = f"https://download.nlm.nih.gov/umls/kss/rxnorm/RxNorm_full_{version}.zip"

        # Initialize Cloud Storage
        storage_client = storage.Client()
        bucket = storage_client.bucket(source_bucket)
        blob_name = f"rxnorm/{version}/RxNorm_full_{version}.zip"
        blob = bucket.blob(blob_name)

        # Check if file already exists
        if blob.exists():
            logger.info(f"File already exists: gs://{source_bucket}/{blob_name}")
            return {
                'status': 'skipped',
                'message': 'File already exists',
                'gcs_uri': f"gs://{source_bucket}/{blob_name}",
                'version': version,
                'terminology': 'rxnorm'
            }

        logger.info(f"Downloading RxNorm from: {download_url}")

        # Stream download with authentication
        headers = {
            'apikey': umls_api_key,
            'Accept': 'application/zip'
        }

        hasher = hashlib.sha256()
        bytes_downloaded = 0
        chunk_size = 10 * 1024 * 1024  # 10MB chunks

        with requests.get(download_url, headers=headers, stream=True, timeout=3600) as r:
            r.raise_for_status()

            # Get file size from headers
            file_size = int(r.headers.get('content-length', 0))
            logger.info(f"Expected file size: {file_size / (1024**2):.2f} MB")

            # Stream to Cloud Storage
            with blob.open("wb", chunk_size=chunk_size) as f:
                for chunk in r.iter_content(chunk_size=chunk_size):
                    if chunk:
                        f.write(chunk)
                        hasher.update(chunk)
                        bytes_downloaded += len(chunk)

                        # Log progress every 100MB
                        if bytes_downloaded % (100 * 1024 * 1024) < chunk_size:
                            mb_downloaded = bytes_downloaded / (1024**2)
                            logger.info(f"Downloaded: {mb_downloaded:.2f} MB")

        sha256_hash = hasher.hexdigest()

        # Set metadata
        blob.metadata = {
            'version': version,
            'source': 'NIH UMLS',
            'sha256': sha256_hash,
            'file_size_bytes': str(bytes_downloaded),
            'download_timestamp': datetime.utcnow().isoformat(),
            'environment': environment,
            'terminology': 'rxnorm'
        }
        blob.patch()

        logger.info(f"Download complete: {bytes_downloaded / (1024**2):.2f} MB")
        logger.info(f"SHA256: {sha256_hash}")
        logger.info(f"Successfully uploaded to: gs://{source_bucket}/{blob_name}")

        return {
            'status': 'success',
            'message': 'Download complete',
            'gcs_uri': f"gs://{source_bucket}/{blob_name}",
            'gcs_key': blob_name,
            'version': version,
            'sha256': sha256_hash,
            'file_size_bytes': bytes_downloaded,
            'terminology': 'rxnorm',
            'timestamp': datetime.utcnow().isoformat()
        }

    except requests.exceptions.RequestException as e:
        logger.error(f"HTTP request failed: {str(e)}")
        return {
            'status': 'failed',
            'error': 'HTTP request failed',
            'error_type': 'RequestException',
            'details': str(e)
        }, 500

    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}", exc_info=True)
        return {
            'status': 'failed',
            'error': 'Unexpected error',
            'error_type': type(e).__name__,
            'details': str(e)
        }, 500

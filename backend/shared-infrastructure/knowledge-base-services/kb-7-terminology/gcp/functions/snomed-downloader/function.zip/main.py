"""
SNOMED CT Downloader - GCP Cloud Function
Downloads SNOMED CT from NHS TRUD API and streams to Cloud Storage
"""

import os
import hashlib
import logging
import json
from datetime import datetime
from google.cloud import storage
from google.cloud import secretmanager
import requests
import functions_framework

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@functions_framework.http
def download_snomed(request):
    """
    Cloud Function to download SNOMED CT from NHS TRUD API
    Streams directly to Cloud Storage (no local disk needed)

    Args:
        request: Flask request object

    Returns:
        JSON response with download status and metadata
    """

    try:
        # Get configuration from environment
        project_id = os.environ['PROJECT_ID']
        source_bucket = os.environ['SOURCE_BUCKET']
        environment = os.environ['ENVIRONMENT']
        secret_name = os.environ['SECRET_NAME']

        logger.info(f"Starting SNOMED CT download for environment: {environment}")

        # Retrieve API key from Secret Manager
        secret_client = secretmanager.SecretManagerServiceClient()
        secret_path = f"projects/{project_id}/secrets/{secret_name}/versions/latest"

        logger.info(f"Retrieving API key from Secret Manager: {secret_name}")
        api_key_response = secret_client.access_secret_version(name=secret_path)
        api_key = api_key_response.payload.data.decode('UTF-8')

        # NHS TRUD API endpoint
        trud_url = f"https://isd.digital.nhs.uk/trud/api/v1/keys/{api_key}/items/SNOMED/releases"

        # Get latest release metadata
        logger.info("Fetching SNOMED release metadata from NHS TRUD API")
        headers = {'Accept': 'application/json'}
        response = requests.get(trud_url, headers=headers, timeout=30)
        response.raise_for_status()

        releases = response.json().get('releases', [])
        if not releases:
            raise ValueError("No SNOMED releases found in API response")

        # Sort by release date and get latest
        latest_release = sorted(releases, key=lambda x: x['releaseDate'], reverse=True)[0]

        download_url = latest_release['archiveFileUrl']
        version = latest_release['releaseDate'].replace('-', '')
        file_size = latest_release.get('archiveFileSize', 0)
        checksum = latest_release.get('checksum', '')

        logger.info(f"Latest SNOMED version: {version}")
        logger.info(f"File size: {file_size / (1024**3):.2f} GB")
        logger.info(f"Download URL: {download_url}")

        # Initialize Cloud Storage client
        storage_client = storage.Client()
        bucket = storage_client.bucket(source_bucket)
        blob_name = f"snomed-ct/{version}/SnomedCT_international_{version}.zip"
        blob = bucket.blob(blob_name)

        # Check if file already exists
        if blob.exists():
            logger.info(f"File already exists: gs://{source_bucket}/{blob_name}")
            return {
                'status': 'skipped',
                'message': 'File already exists',
                'gcs_uri': f"gs://{source_bucket}/{blob_name}",
                'version': version,
                'terminology': 'snomed',
                'file_size_bytes': file_size
            }

        logger.info(f"Starting download to: gs://{source_bucket}/{blob_name}")

        # Stream download to Cloud Storage with hash calculation
        hasher = hashlib.sha256()
        bytes_downloaded = 0
        chunk_size = 10 * 1024 * 1024  # 10MB chunks

        with requests.get(download_url, stream=True, timeout=3600) as r:
            r.raise_for_status()

            # Use blob.open() for streaming upload (simpler than multipart!)
            with blob.open("wb", chunk_size=chunk_size) as f:
                for chunk in r.iter_content(chunk_size=chunk_size):
                    if chunk:
                        f.write(chunk)
                        hasher.update(chunk)
                        bytes_downloaded += len(chunk)

                        # Log progress every GB
                        if bytes_downloaded % (1024**3) < chunk_size:
                            gb_downloaded = bytes_downloaded / (1024**3)
                            logger.info(f"Downloaded: {gb_downloaded:.2f} GB")

        sha256_hash = hasher.hexdigest()

        # Set metadata on blob
        blob.metadata = {
            'version': version,
            'source': 'NHS TRUD API',
            'sha256': sha256_hash,
            'file_size_bytes': str(bytes_downloaded),
            'download_timestamp': datetime.utcnow().isoformat(),
            'environment': environment,
            'terminology': 'snomed'
        }
        blob.patch()

        logger.info(f"Download complete: {bytes_downloaded / (1024**3):.2f} GB")
        logger.info(f"SHA256: {sha256_hash}")
        logger.info(f"Successfully uploaded to: gs://{source_bucket}/{blob_name}")

        # Return success response
        return {
            'status': 'success',
            'message': 'Download complete',
            'gcs_uri': f"gs://{source_bucket}/{blob_name}",
            'gcs_key': blob_name,
            'version': version,
            'sha256': sha256_hash,
            'file_size_bytes': bytes_downloaded,
            'terminology': 'snomed',
            'timestamp': datetime.utcnow().isoformat()
        }

    except requests.exceptions.RequestException as e:
        logger.error(f"HTTP request failed: {str(e)}")
        return {
            'status': 'failed',
            'error': 'HTTP request failed',
            'error_type': 'RequestException',
            'details': str(e)
        }, 500

    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}", exc_info=True)
        return {
            'status': 'failed',
            'error': 'Unexpected error',
            'error_type': type(e).__name__,
            'details': str(e)
        }, 500

"""
LOINC Downloader - GCP Cloud Function
Downloads LOINC from LOINC.org and streams to Cloud Storage
"""

import os
import hashlib
import logging
import json
from datetime import datetime
from google.cloud import storage
from google.cloud import secretmanager
import requests
from requests.auth import HTTPBasicAuth
import functions_framework

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@functions_framework.http
def download_loinc(request):
    """
    Cloud Function to download LOINC from LOINC.org

    Args:
        request: Flask request object

    Returns:
        JSON response with download status and metadata
    """

    try:
        # Get configuration
        project_id = os.environ['PROJECT_ID']
        source_bucket = os.environ['SOURCE_BUCKET']
        environment = os.environ['ENVIRONMENT']
        secret_name = os.environ['SECRET_NAME']

        logger.info(f"Starting LOINC download for environment: {environment}")

        # Retrieve LOINC credentials from Secret Manager
        secret_client = secretmanager.SecretManagerServiceClient()
        secret_path = f"projects/{project_id}/secrets/{secret_name}/versions/latest"

        logger.info(f"Retrieving LOINC credentials from Secret Manager")
        credentials_response = secret_client.access_secret_version(name=secret_path)
        credentials = json.loads(credentials_response.payload.data.decode('UTF-8'))

        loinc_username = credentials['username']
        loinc_password = credentials['password']

        # Get LOINC version metadata
        logger.info("Fetching LOINC version metadata")
        version_url = "https://loinc.org/download/loinc-version-info/"

        version_response = requests.get(
            version_url,
            auth=HTTPBasicAuth(loinc_username, loinc_password),
            timeout=30
        )
        version_response.raise_for_status()

        # Parse version from response (format varies, use date as fallback)
        version = datetime.now().strftime('%Y%m')  # YYYYMM format
        logger.info(f"LOINC version: {version}")

        # LOINC download URL
        download_url = f"https://loinc.org/downloads/loinc/loinc-complete.zip"

        # Initialize Cloud Storage
        storage_client = storage.Client()
        bucket = storage_client.bucket(source_bucket)
        blob_name = f"loinc/{version}/loinc-complete-{version}.zip"
        blob = bucket.blob(blob_name)

        # Check if file already exists
        if blob.exists():
            logger.info(f"File already exists: gs://{source_bucket}/{blob_name}")
            return {
                'status': 'skipped',
                'message': 'File already exists',
                'gcs_uri': f"gs://{source_bucket}/{blob_name}",
                'version': version,
                'terminology': 'loinc'
            }

        logger.info(f"Downloading LOINC from: {download_url}")

        # Stream download with authentication
        hasher = hashlib.sha256()
        bytes_downloaded = 0
        chunk_size = 10 * 1024 * 1024  # 10MB chunks

        with requests.get(
            download_url,
            auth=HTTPBasicAuth(loinc_username, loinc_password),
            stream=True,
            timeout=1800
        ) as r:
            r.raise_for_status()

            # Get file size from headers
            file_size = int(r.headers.get('content-length', 0))
            logger.info(f"Expected file size: {file_size / (1024**2):.2f} MB")

            # Stream to Cloud Storage
            with blob.open("wb", chunk_size=chunk_size) as f:
                for chunk in r.iter_content(chunk_size=chunk_size):
                    if chunk:
                        f.write(chunk)
                        hasher.update(chunk)
                        bytes_downloaded += len(chunk)

                        # Log progress every 50MB
                        if bytes_downloaded % (50 * 1024 * 1024) < chunk_size:
                            mb_downloaded = bytes_downloaded / (1024**2)
                            logger.info(f"Downloaded: {mb_downloaded:.2f} MB")

        sha256_hash = hasher.hexdigest()

        # Set metadata
        blob.metadata = {
            'version': version,
            'source': 'LOINC.org',
            'sha256': sha256_hash,
            'file_size_bytes': str(bytes_downloaded),
            'download_timestamp': datetime.utcnow().isoformat(),
            'environment': environment,
            'terminology': 'loinc'
        }
        blob.patch()

        logger.info(f"Download complete: {bytes_downloaded / (1024**2):.2f} MB")
        logger.info(f"SHA256: {sha256_hash}")
        logger.info(f"Successfully uploaded to: gs://{source_bucket}/{blob_name}")

        return {
            'status': 'success',
            'message': 'Download complete',
            'gcs_uri': f"gs://{source_bucket}/{blob_name}",
            'gcs_key': blob_name,
            'version': version,
            'sha256': sha256_hash,
            'file_size_bytes': bytes_downloaded,
            'terminology': 'loinc',
            'timestamp': datetime.utcnow().isoformat()
        }

    except requests.exceptions.RequestException as e:
        logger.error(f"HTTP request failed: {str(e)}")
        return {
            'status': 'failed',
            'error': 'HTTP request failed',
            'error_type': 'RequestException',
            'details': str(e)
        }, 500

    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}", exc_info=True)
        return {
            'status': 'failed',
            'error': 'Unexpected error',
            'error_type': type(e).__name__,
            'details': str(e)
        }, 500
